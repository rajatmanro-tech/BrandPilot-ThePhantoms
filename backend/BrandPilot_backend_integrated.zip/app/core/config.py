
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str

    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    GEMINI_API_KEY: str
    GEMINI_MODEL: str = "gemini-3.8-flash"
    OPENAI_API_KEY: str
    OPENAI_MODEL: str = "gpt-4.1-mini"
    GROQ_API_KEY: str
    GROQ_MODEL: str = "openai/gpt-oss-20b"
    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore"
    )


settings = Settings()
